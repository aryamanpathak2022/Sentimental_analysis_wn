# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has on_delete set to the desired behavior.
#   * Remove managed = False lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

class Bed(models.Model):
    id = models.BigIntegerField(primary_key=True)
    is_occupied = models.BooleanField()
    room_id = models.IntegerField()
    # guestEntity = models.ForeignKey(GuestEntity, null=True, related_name="bed")

    def str(self) -> str:
        return f"Room {self.room_id} Bed {self.id}"

    class Meta:
        # managed = False
        db_table = "bed"

class GuestEntity(models.Model):
    id = models.BigIntegerField(primary_key=True)
    emergencyphonenumber = models.CharField(max_length=255, blank=True, null=True)
    firstname = models.CharField(max_length=255, null=False)
    foodservice = models.BooleanField(blank=True, null=True)
    lastname = models.CharField(max_length=255, null=False)
    laundryservice = models.BooleanField(blank=True, null=True)
    noticeperiod = models.DateField(blank=True, null=True)
    phonenumber = models.CharField(unique=True, max_length=255)
    proofvalue = models.CharField(max_length=255, null=False)
    bed = models.ForeignKey(Bed, null=False, related_name="guestEntity", on_delete=models.DO_NOTHING)
    prooftype = models.CharField(max_length=14)

    def str(self) -> str:
        return f"{self.firstname} {self.lastname}"


    class Meta:
        # managed = False
        db_table = "guest_entity"

class User(models.Model):
    user_id = models.BigIntegerField(primary_key=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(unique=True, max_length=255)
    location = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    number = models.CharField(unique=True, max_length=255)
    password = models.CharField(max_length=255, blank=True, null=True)
    role = models.CharField(max_length=5, blank=True, null=True)

    def str(self) -> str:
        return f"{self.email}"

    class Meta:
        # managed = False
        db_table = "user"

class PgStats(models.Model):
    id = models.BigAutoField(primary_key=True)
    num_floors = models.IntegerField()
    num_occ = models.IntegerField()
    num_of_beds_each = models.IntegerField()
    num_of_rooms_each = models.IntegerField()
    num_vacant = models.IntegerField()
    owner = models.ForeignKey(User , models.DO_NOTHING, unique=True, null=False)

    def str(self) -> str:
        return f"ID {self.id}"

    class Meta:
        # managed = False
        db_table = "pg_stats"


class BedSeq(models.Model):
    next_val = models.BigIntegerField(blank=True, null=True)

    class Meta:
        # managed = False
        db_table = "bed_seq"


class ConfirmationToken(models.Model):
    id = models.BigIntegerField(primary_key=True)
    confirmed_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField()
    expires_at = models.DateTimeField()
    token = models.CharField(max_length=255)
    user = models.ForeignKey(User, models.DO_NOTHING)

    class Meta:
        # managed = False
        db_table = "confirmation_token"


class ConfirmationTokenSeq(models.Model):
    next_val = models.BigIntegerField(blank=True, null=True)

    class Meta:
        # managed = False
        db_table = "confirmation_token_seq"


class GuestEntitySeq(models.Model):
    next_val = models.BigIntegerField(blank=True, null=True)

    class Meta:
        # managed = False
        db_table = "guest_entity_seq"


class UserSeq(models.Model):
    next_val = models.BigIntegerField(blank=True, null=True)

    class Meta:
        # managed = False
        db_table = "user_seq"