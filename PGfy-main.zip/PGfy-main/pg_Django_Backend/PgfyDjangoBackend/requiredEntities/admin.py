from django.contrib import admin
from requiredEntities.models import Bed, BedSeq, GuestEntity, GuestEntitySeq, User, UserSeq, PgStats, ConfirmationToken, ConfirmationTokenSeq

admin.site.register(Bed)
admin.site.register(BedSeq)
admin.site.register(GuestEntity)
admin.site.register(GuestEntitySeq)
admin.site.register(User)
admin.site.register(UserSeq)
admin.site.register(PgStats)
admin.site.register(ConfirmationToken)
admin.site.register(ConfirmationTokenSeq)

# Register your models here.
