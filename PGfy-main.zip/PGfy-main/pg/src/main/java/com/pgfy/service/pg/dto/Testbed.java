package com.pgfy.service.pg.dto;

public class Testbed {

    private String booll;

    private int roomId;

    public String getBooll() {
        return booll;
    }

    public void setBooll(String booll) {
        this.booll = booll;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
}
