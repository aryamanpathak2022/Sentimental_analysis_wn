package com.pgfy.service.pg.repo;

public interface GuestRepo extends UserRepo{
}
