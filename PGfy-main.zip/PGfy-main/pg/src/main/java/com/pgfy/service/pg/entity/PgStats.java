package com.pgfy.service.pg.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class PgStats {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "owner_id",nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private UserEntity owner;
    private int num_floors;

    private int num_of_rooms_each;

    private int num_of_beds_each;

    private int num_occ;

    private int num_vacant;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getFloornum() {
        return num_floors;
    }

    public void setFloornum(int floornum) {
        this.num_floors = floornum;
    }

    public int getRoomnum() {
        return num_of_rooms_each;
    }

    public void setRoomnum(int roomnum) {
        this.num_of_rooms_each = roomnum;
    }

    public int getBeds() {
        return num_of_beds_each;
    }

    public void setBeds(int beds) {
        this.num_of_beds_each = beds;
    }

    public int getNum_occ() {
        return num_occ;
    }

    public void setNum_occ(int num_occ) {
        this.num_occ = num_occ;
    }

    public int getNum_vacant() {
        return num_vacant;
    }

    public void setNum_vacant(int num_vacant) {
        this.num_vacant = num_vacant;
    }

    public UserEntity getOwner() {
        return owner;
    }

    public void setOwner(UserEntity owner) {
        this.owner = owner;
    }
}
