package com.pgfy.service.pg.cont;

import com.pgfy.service.pg.entity.UserEntity;
import com.pgfy.service.pg.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<UserEntity> getUserByID(@PathVariable Long id) {
        return ResponseEntity.ok().body(userService.getUserById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUserById(@PathVariable Long id) {
        return ResponseEntity.ok().body(userService.deleteUserById(id));
    }

//    @GetMapping("")
//    public ResponseEntity<List<User>> getAllUsers() {
//        return ResponseEntity.ok().body(userService.getUsers());
//    }
}
