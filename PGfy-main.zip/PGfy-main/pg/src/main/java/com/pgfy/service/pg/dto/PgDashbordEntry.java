package com.pgfy.service.pg.dto;

public class PgDashbordEntry {

    private int floornumber;

    private int roomnumber;

    private int num_of_beds;

    private int num_vacant;

    private int num_occupied;

    public PgDashbordEntry(){

    }

    public int getFloornumber() {
        return floornumber;
    }

    public void setFloornumber(int floornumber) {
        this.floornumber = floornumber;
    }

    public int getRoomnumber() {
        return roomnumber;
    }

    public void setRoomnumber(int roomnumber) {
        this.roomnumber = roomnumber;
    }

    public int getNum_of_beds() {
        return num_of_beds;
    }

    public void setNum_of_beds(int num_of_beds) {
        this.num_of_beds = num_of_beds;
    }

    public int getNum_vacant() {
        return num_vacant;
    }

    public void setNum_vacant(int num_vacant) {
        this.num_vacant = num_vacant;
    }

    public int getNum_occupied() {
        return num_occupied;
    }

    public void setNum_occupied(int num_occupied) {
        this.num_occupied = num_occupied;
    }
}
