package com.pgfy.service.pg.dto;

import com.pgfy.service.pg.entity.GuestEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BedDto {
    private Long id;
//    private boolean isOccupied;
//    private int roomId;
//    private GuestDto guestDto;
//
//    public Bed convert_To_Entity() {
//        return new Bed(this.getId(), this.isOccupied(), this.getRoomId(), this.getGuestDto().convert_To_Entity());
//    }
}
