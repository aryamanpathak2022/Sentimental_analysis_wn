package com.pgfy.service.pg.cont;

import com.pgfy.service.pg.dto.PgDashbordEntry;
import com.pgfy.service.pg.dto.PgDetails;
import com.pgfy.service.pg.dto.Testbed;
import com.pgfy.service.pg.service.PgService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/pg")
public class pgdetailscont {

    private final PgService pgService;

    public pgdetailscont(PgService pgService) {
        this.pgService = pgService;
    }

    @PostMapping("/pgdetails/{userId}")
    public ResponseEntity<?> postPgDetails(@RequestBody PgDetails pgDetails,@PathVariable Long userId){
        pgService.postDetails(pgDetails,userId);
        Map<String,String> okmap=new HashMap<>();
        okmap.put("message","PgDetails Posted successfully");
        return ResponseEntity.ok().body(okmap);
    }
    @GetMapping("/pgdetails/dashboard/{userId}")
    public ResponseEntity<?> getPgDetails(@PathVariable Long userId) {

        List<PgDashbordEntry> pgDashbordEntries=pgService.getDetails(userId);

        if(pgDashbordEntries.isEmpty()){
            Map<String,String> notfoundmap=new HashMap<>();
            notfoundmap.put("message","Empty details");
            return ResponseEntity.ok().body(notfoundmap);
        }
        return ResponseEntity.ok().body(pgDashbordEntries);
    }
    @PostMapping("/pgdetails/changeocc/{userId}")
    public ResponseEntity<?> changeocc(@PathVariable Long userId, @RequestBody Testbed testbed){
        pgService.changeOcc(userId,testbed);
        Map<String,String> notfoundmap=new HashMap<>();
        notfoundmap.put("message","changed");
        return ResponseEntity.ok().body(notfoundmap);
    }
}
