package com.pgfy.service.pg.entity;

import com.pgfy.service.pg.enums.ProofType;
import com.pgfy.service.pg.enums.Role;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Data
@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
//@MappedSuperclass
public abstract class UserEntity implements UserDetails {
        @Id
        @Column(name = "user_id")
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;
        @Column(unique = true, nullable = false)
        private String number;
        @Column(nullable = false)
        private String firstName;
        @Column(nullable = false)
        private String lastName;
        @Column(unique = true, nullable = false)
        private String email;
        @Column(nullable = false)
        private String password;
        @Enumerated(EnumType.STRING)
        @Column(nullable = false)
        private Role role;
//        @Column(nullable = false)
//        @Enumerated(EnumType.STRING)
//        private ProofType prooftype;
//        @Column(nullable = false)
//        private String proofvalue;

        public UserEntity(){ }

        public UserEntity(String firstName, String email, String password, String lastName, String number, Role role) {
                this.firstName = firstName;
                this.lastName = lastName;
                this.email = email;
                this.password = password;
                this.number = number;
                this.role = role;
        }

        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
                return List.of(new SimpleGrantedAuthority(role.name()));
        }

        @Override
        public String getPassword() {
                return password;
        }

        @Override
        public String getUsername() {
                return email;
        }

        @Override
        public boolean isAccountNonExpired() {
                return true;
        }

        @Override
        public boolean isAccountNonLocked() {
                return true;
        }

        @Override
        public boolean isCredentialsNonExpired() {
                return true;
        }

        @Override
        public boolean isEnabled() {
                return true;
        }
}
