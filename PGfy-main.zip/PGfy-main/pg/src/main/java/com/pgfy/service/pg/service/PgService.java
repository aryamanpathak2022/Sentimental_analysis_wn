package com.pgfy.service.pg.service;

import com.pgfy.service.pg.dto.PgDashbordEntry;
import com.pgfy.service.pg.dto.PgDetails;
import com.pgfy.service.pg.dto.Testbed;
import org.springframework.stereotype.Service;

import java.util.List;


public interface PgService {
    void postDetails(PgDetails pgDetails, Long userId);

    List<PgDashbordEntry> getDetails(Long userId);

    void changeOcc(Long userId, Testbed testbed);
}
