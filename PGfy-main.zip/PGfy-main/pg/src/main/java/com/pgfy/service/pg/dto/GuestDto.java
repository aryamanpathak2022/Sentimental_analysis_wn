package com.pgfy.service.pg.dto;

import com.pgfy.service.pg.enums.ChoosingBed;
import com.pgfy.service.pg.enums.ProofType;
import com.pgfy.service.pg.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GuestDto {

    private Long id;
    private String number;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private ProofType proofType;
    private String proofValue;
    private Role role;
    private String emergencyphonenumber;
    private Boolean foodservice;
    private Boolean laundryservice;
    private LocalDate noticeperiod;
    private Boolean amenityservice;
    private Boolean transportationservice;
    private LocalDate checkindate;
    private LocalDate checkoutdate;
    private Boolean paymenttoowner;
    private ChoosingBed choosingBed;
}
