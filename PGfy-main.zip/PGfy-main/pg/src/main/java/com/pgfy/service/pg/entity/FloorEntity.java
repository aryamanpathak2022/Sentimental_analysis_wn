package com.pgfy.service.pg.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class FloorEntity {
    @Id
    @Column(name = "floor_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String shortname;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hostel_id")
    private PGHostelEntity pgHostelEntity;
    @OneToMany(mappedBy = "floorEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RoomEntity> roomEntities;
}
