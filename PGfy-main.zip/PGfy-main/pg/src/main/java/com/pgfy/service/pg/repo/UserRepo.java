package com.pgfy.service.pg.repo;

import com.pgfy.service.pg.entity.UserEntity;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
@Primary
public interface UserRepo extends JpaRepository<UserEntity, Long> {

    @Query("select u from UserEntity u where u.email = ?1")
    Optional<UserEntity> findByEmail(String email);

    @Query("select u from UserEntity u where u.number = ?1")
    Optional<UserEntity> findByNumber(String number);

    @Modifying
    @Transactional
    @Query("update UserEntity u set u.password = ?1 where u.id = ?2")
    void updatePasswordById(String password, Long id);

}
