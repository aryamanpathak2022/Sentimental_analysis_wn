package com.pgfy.service.pg.service;

import com.pgfy.service.pg.entity.UserEntity;

import java.util.List;

public interface UserService {
    Void deleteUserById(Long id);
    UserEntity getUserById(Long id);

    List<UserEntity> getUsers();
}
