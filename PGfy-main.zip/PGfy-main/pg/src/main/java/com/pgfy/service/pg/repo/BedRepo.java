package com.pgfy.service.pg.repo;

import com.pgfy.service.pg.entity.BedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BedRepo extends JpaRepository<BedEntity,Long> {
//    List<BedEntity> findByRoomId(int i);
}
