package com.pgfy.service.pg.repo;

import com.pgfy.service.pg.entity.PgStats;
import com.pgfy.service.pg.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PgStatsRepo extends JpaRepository<PgStats,Long> {
    PgStats findByOwner(UserEntity userEntity);
}
