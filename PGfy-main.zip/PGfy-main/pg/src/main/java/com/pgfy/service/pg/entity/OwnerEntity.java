package com.pgfy.service.pg.entity;

import com.pgfy.service.pg.enums.ProofType;
import com.pgfy.service.pg.enums.Role;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@PrimaryKeyJoinColumn(name = "owner_id")
//@AttributeOverrides({
//        @AttributeOverride(name = "id", column = @Column(name="owner_id"))
//})
public class OwnerEntity extends UserEntity {
    @OneToMany(mappedBy = "ownerEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PGHostelEntity> pgHostelEntities;
    @Enumerated(EnumType.STRING)
    private ProofType proofType;
    private String proofValue;

    public OwnerEntity(String firstName, String email, String password, String lastName, String number, Role role, ProofType proofType, String proofValue) {
        super(firstName, email, password, lastName, number, role);
        this.proofType = proofType;
        this.proofValue = proofValue;
    }
}
