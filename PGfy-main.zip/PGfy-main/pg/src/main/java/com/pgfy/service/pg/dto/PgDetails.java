package com.pgfy.service.pg.dto;

public class PgDetails {

    private int num_of_floors;

    private int num_of_rooms_in_each_floor;

    private int num_beds_each_room;

    public PgDetails(){

    }

    public int getNum_of_floors() {
        return num_of_floors;
    }

    public void setNum_of_floors(int num_of_floors) {
        this.num_of_floors = num_of_floors;
    }

    public int getNum_of_rooms_in_each_floor() {
        return num_of_rooms_in_each_floor;
    }

    public void setNum_of_rooms_in_each_floor(int num_of_rooms_in_each_floor) {
        this.num_of_rooms_in_each_floor = num_of_rooms_in_each_floor;
    }

    public int getNum_beds_each_room() {
        return num_beds_each_room;
    }

    public void setNum_beds_each_room(int num_beds_each_room) {
        this.num_beds_each_room = num_beds_each_room;
    }
}
