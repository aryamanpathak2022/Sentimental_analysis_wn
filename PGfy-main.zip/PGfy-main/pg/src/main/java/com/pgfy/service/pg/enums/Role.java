package com.pgfy.service.pg.enums;

public enum Role {
    ADMIN,
    GUEST,
    OWNER,
    PREMIUMOWNER,
    PREMIUMCUSTOMER
}
