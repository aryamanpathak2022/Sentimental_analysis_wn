package com.pgfy.service.pg.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BedEntity {
    @Id
    @Column(name = "bed_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Boolean isOccupied;
    private Integer perdaycharge;
    private String shortname;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id")
    private RoomEntity roomEntity;
//    @OneToOne(mappedBy = "id")
    @OneToOne
    @JoinColumn(name = "guest_id")
    private GuestEntity guestEntity;

}
