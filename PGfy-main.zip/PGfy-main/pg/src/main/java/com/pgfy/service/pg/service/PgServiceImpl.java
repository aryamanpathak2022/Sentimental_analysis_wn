package com.pgfy.service.pg.service;

import com.pgfy.service.pg.dto.PgDashbordEntry;
import com.pgfy.service.pg.dto.PgDetails;
import com.pgfy.service.pg.dto.Testbed;
import com.pgfy.service.pg.entity.*;
import com.pgfy.service.pg.repo.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service

public class PgServiceImpl implements PgService {

    private final UserRepo userRepo;
    private final PgStatsRepo pgStatsRepo;

    private final BedRepo bedRepo;

    public PgServiceImpl(UserRepo userRepo, PgStatsRepo pgStatsRepo, BedRepo bedRepo) {
        this.userRepo = userRepo;
        this.pgStatsRepo = pgStatsRepo;

        this.bedRepo = bedRepo;
    }

    @Override
    public void postDetails(PgDetails pgDetails, Long userId) {
        UserEntity userEntity = userRepo.findById(userId).get();
        System.out.println(userEntity);
        PgStats pgStats = new PgStats();


        int num_floors = pgDetails.getNum_of_floors();
        int num_rooms_per_floor = pgDetails.getNum_of_rooms_in_each_floor();
        int beds = pgDetails.getNum_beds_each_room();
        pgStats.setFloornum(num_floors);
        pgStats.setBeds(beds);
        pgStats.setRoomnum(num_rooms_per_floor);
        pgStats.setNum_occ(0);
        pgStats.setNum_vacant(beds);
        pgStats.setOwner(userEntity);
        pgStatsRepo.save(pgStats);
        for (int i = 1; i <= num_floors; i++) {
            for (int j = 1; j <= num_rooms_per_floor; j++) {
                for (int k = 1; k <= beds; k++) {
                    BedEntity bed = new BedEntity();
                    bed.setIsOccupied(false);
//                    bed.setRoomId(100*i+j);
                    bedRepo.save(bed);
                }
            }
        }


    }

    @Override
    public List<PgDashbordEntry> getDetails(Long userId) {
        return null;
//        UserEntity userEntity =userRepo.findById(userId).get();
//        PgStats pgStats=pgStatsRepo.findByOwner(userEntity);
//        System.out.println(pgStats.getBeds());
//        List<PgDashbordEntry> pgDashbordEntries=new ArrayList<>();
//        for(int i=1;i<=pgStats.getFloornum();i++){
//            System.out.println(i);
//            for(int j=1;j<= pgStats.getRoomnum();j++){
//
//                PgDashbordEntry pgDashbordEntry=new PgDashbordEntry();
//                pgDashbordEntry.setFloornumber(i);
//                pgDashbordEntry.setRoomnumber(i*100+j);
//                pgDashbordEntry.setNum_of_beds(pgStats.getBeds());
//                List<BedEntity> beds =bedRepo.findByRoomId(i*100+j);
//                int vac = 0;
//                int occ = 0;
//                for(BedEntity bed: beds) {
//                    boolean isocc = bed.getIsOccupied();
//                    if (isocc == Boolean.FALSE) {
//                        vac++;
//                    } else {
//                        occ++;
//                    }
//                }
//
//                pgDashbordEntry.setNum_vacant(vac);
//                pgDashbordEntry.setNum_occupied(occ);
//                pgDashbordEntries.add(pgDashbordEntry);
//            }
//        }
//        System.out.println(pgDashbordEntries);
//        return pgDashbordEntries;
    }

    @Override
    public void changeOcc(Long userId, Testbed testbed) {
//        UserEntity userEntity =userRepo.findById(userId).get();
//        PgStats pgStats=pgStatsRepo.findByOwner(userEntity);
//        List<BedEntity> beds =bedRepo.findByRoomId(testbed.getRoomId());
//        for(BedEntity bed: beds){
//            if(!bed.getIsOccupied()){
//                if(testbed.getBooll().equals("true")){
//
//                    bed.setIsOccupied(Boolean.TRUE);
//                    bedRepo.save(bed);
//                    return;
//                }
//            }
//  }


    }
}
