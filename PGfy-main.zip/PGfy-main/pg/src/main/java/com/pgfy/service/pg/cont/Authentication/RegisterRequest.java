package com.pgfy.service.pg.cont.Authentication;


import com.pgfy.service.pg.enums.Role;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private Long id;
    private String number;
    private String name;
    private String address;
    private String email;
    private String password;
    private String location;
    private Role role;
}

