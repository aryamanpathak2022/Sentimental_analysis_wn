package com.pgfy.service.pg.enums;

public enum ChoosingBed {
    ONLINE,
    OFFLINE
}
