package com.pgfy.service.pg.entity;

import com.pgfy.service.pg.enums.ChoosingBed;
import com.pgfy.service.pg.enums.ProofType;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Getter
@Setter
@PrimaryKeyJoinColumn(name = "guest_id")
//@AttributeOverrides({
//        @AttributeOverride(name = "id", column = @Column(name="guest_id"))
//})
public class GuestEntity extends UserEntity {
    // @Id
    // @Column(name = "guest_id")
    // @GeneratedValue(strategy = GenerationType.AUTO)
    // private Long id;
    // @Column(nullable = false)
    // private String firstname;
    // @Column(nullable = false)
    // private String lastname;
    // @Column(nullable = false, unique = true)
    // private String phonenumber;
    // @AttributeOverrides({
    //         @AttributeOverride(name = "user_id", column = @Column(name = "guest_id"))
    // })
    private String emergencyphonenumber;
    private Boolean foodservice;
    private Boolean laundryservice;
    private LocalDate noticeperiod;
    private Boolean amenityservice;
    private Boolean transportationservice;
    private LocalDate checkindate;
    private LocalDate checkoutdate;
    private Boolean paymenttoowner;
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private ProofType proofType;
    @Column(nullable = false)
    private String proofValue;
    private ChoosingBed choosingBed;
//    @PrimaryKeyJoinColumn
//    @OneToOne(mappedBy = "bed_id")
    @OneToOne
    @JoinColumn(nullable = false, name = "bed_id")
    private BedEntity bedEntity;
}
