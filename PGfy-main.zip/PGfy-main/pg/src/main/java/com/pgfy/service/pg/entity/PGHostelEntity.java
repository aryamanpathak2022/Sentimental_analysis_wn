package com.pgfy.service.pg.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Getter
@Setter
public class PGHostelEntity {
    @Id
    @Column(name = "hostel_id")
    @GeneratedValue
    private Long id;
    private String address;
    private String amenitiesAvailable;
    private String fullname;
    private String shortname;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "owner_id")
    private OwnerEntity ownerEntity;
    @OneToMany(mappedBy = "pgHostelEntity", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FloorEntity> floorEntities;
}
