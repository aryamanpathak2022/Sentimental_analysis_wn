package com.pgfy.service.pg.repo;

public interface OwnerRepo extends UserRepo{

}
