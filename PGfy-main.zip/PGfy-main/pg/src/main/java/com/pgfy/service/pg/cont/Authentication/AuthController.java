package com.pgfy.service.pg.cont.Authentication;

import com.pgfy.service.pg.dto.GuestDto;
import com.pgfy.service.pg.dto.OwnerDto;
import com.pgfy.service.pg.exceptions.TokenNotFoundException;
import com.pgfy.service.pg.service.AuthenticationService;
import com.pgfy.service.pg.service.ForgotPasswordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationService service;
    private final ForgotPasswordService forgotPasswordService;
    private static final Logger logger = Logger.getLogger(AuthController.class.getName());

    @PostMapping("/register-owner")
    public ResponseEntity<AuthenticationResponse> register(
            @RequestBody OwnerDto request
    ) {
        logger.info("Entered the controller");
        return ResponseEntity.ok(service.registerOwner(request));
    }

    @PostMapping("/register-guest")
    public ResponseEntity<AuthenticationResponse> register(
            @RequestBody GuestDto request
    ) {
        logger.info("Entered the controller");
        return ResponseEntity.ok(service.registerGuest(request));
    }

    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticationResponse> register(
            @RequestBody AuthenticationRequest request
    ) {
        return ResponseEntity.ok(service.authenticate(request));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> confirmEmail(
        @RequestBody ConfirmMailRequest request
    ) {
        return ResponseEntity.ok(forgotPasswordService.sendTokenByEmail(request.getEmail()));
    }

    @PostMapping("/forgot-password/{token}")
    public ResponseEntity<String> changePassword(
        @RequestBody ForgotPasswordRequest request,
        @PathVariable String token
    ) throws TokenNotFoundException {
        logger.info("Entered forgot password-2");
        return ResponseEntity.ok(forgotPasswordService.confirmToken(token, request.getNewPassword()));
    }
}
