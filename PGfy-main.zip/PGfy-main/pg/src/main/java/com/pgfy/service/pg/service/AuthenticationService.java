package com.pgfy.service.pg.service;

import com.pgfy.service.pg.cont.Authentication.AuthenticationRequest;
import com.pgfy.service.pg.cont.Authentication.AuthenticationResponse;
import com.pgfy.service.pg.dto.GuestDto;
import com.pgfy.service.pg.dto.OwnerDto;
import com.pgfy.service.pg.entity.GuestEntity;
import com.pgfy.service.pg.entity.OwnerEntity;
import com.pgfy.service.pg.repo.UserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UserRepo repo;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private static final Logger logger = Logger.getLogger(AuthenticationService.class.getName());
    // create and save user to db

    public AuthenticationResponse registerOwner(OwnerDto request) {
        var user = OwnerEntity.builder()
                .email(request.getEmail())
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .number(request.getNumber())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .proofType(request.getProofType())
                .proofValue(request.getProofValue())
                .build();
        repo.save(user);    // handle integrity violation exceptions
        logger.info("Info saved in this function\n");
        var jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .id(user.getId())
                .role(user.getRole())
                .build();
    }

    public AuthenticationResponse registerGuest(GuestDto request) {
        var user = GuestEntity.builder()
                .email(request.getEmail())
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .number(request.getNumber())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .proofType(request.getProofType())
                .proofValue(request.getProofValue())
                .amenityservice(request.getAmenityservice())
                .paymenttoowner(request.getPaymenttoowner())
                .transportationservice(request.getTransportationservice())
                .checkindate(request.getCheckindate())
                .checkoutdate(request.getCheckoutdate())
                .choosingBed(request.getChoosingBed())
                .emergencyphonenumber(request.getEmergencyphonenumber())
                .foodservice(request.getFoodservice())
                .noticeperiod(request.getNoticeperiod())
                .laundryservice(request.getLaundryservice())
                .build();
        repo.save(user);    // handle integrity violation exceptions
        logger.info("Info saved in this function\n");
        var jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .id(user.getId())
                .role(user.getRole())
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );
        // if user is authenticated
        var user = repo.findByEmail(request.getEmail()).orElseThrow(() -> new UsernameNotFoundException("User doesn't exist"));
        var jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .id(user.getId())
                .role(user.getRole())
                .build();
    }
}
