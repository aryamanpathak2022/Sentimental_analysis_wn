package com.pgfy.service.pg.service;


public interface MailService {
    void send(String to, String email);
}