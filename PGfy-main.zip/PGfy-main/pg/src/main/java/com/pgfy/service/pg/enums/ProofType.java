package com.pgfy.service.pg.enums;

public enum ProofType {
    AADHAR,
    PAN,
    DRIVINGLICENSE,
    VOTERID
}
