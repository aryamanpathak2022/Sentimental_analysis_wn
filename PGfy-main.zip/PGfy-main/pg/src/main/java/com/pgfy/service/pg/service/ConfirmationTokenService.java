package com.pgfy.service.pg.service;

import com.pgfy.service.pg.entity.ConfirmationToken;
import com.pgfy.service.pg.repo.ConfirmationTokenRepo;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ConfirmationTokenService {
        private  final ConfirmationTokenRepo confirmationTokenRepo;
        public void saveConfirmationToken(ConfirmationToken token) {
            confirmationTokenRepo.save(token);
        }

        public Optional<ConfirmationToken> getToken(String token) {
            return confirmationTokenRepo.findByToken(token);
        }

        public void setConfirmedAt(String token) {
            confirmationTokenRepo.updateConfirmedAt(token, LocalDateTime.now());
        }
}
