package com.pgfy.service.pg.service;

import com.pgfy.service.pg.entity.UserEntity;
import com.pgfy.service.pg.repo.UserRepo;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class UserServiceImpl implements UserService{

    private final UserRepo userRepo;
    @Override
    public Void deleteUserById(Long id) {
        Optional<UserEntity> user = userRepo.findById(id);
        if (user.isEmpty())
            throw new EntityNotFoundException("user not found");
        userRepo.deleteById(id);
        return null;
    }

    @Override
    public UserEntity getUserById(Long id) {
        Optional<UserEntity> user = userRepo.findById(id);
        if (user.isEmpty())
            throw new EntityNotFoundException("user not found");
        return user.get();
    }

    @Override
    public List<UserEntity> getUsers() {
        List<UserEntity> userEntities = userRepo.findAll();
        if (userEntities.isEmpty())
            throw new EntityNotFoundException("no users found");
        return userEntities;
    }
}
