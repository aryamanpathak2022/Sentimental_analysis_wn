package com.pgfy.service.pg.exceptions;

public class TokenNotFoundException extends Exception{
    public TokenNotFoundException(String msg) {
        super(msg);
    }
}
