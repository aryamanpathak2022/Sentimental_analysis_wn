package com.pgfy.service.pg.dto;

import com.pgfy.service.pg.enums.ProofType;
import com.pgfy.service.pg.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OwnerDto {

        private Long id;
        private String number;
        private String firstName;
        private String lastName;
        private String email;
        private String password;
        private ProofType proofType;
        private String proofValue;
        private Role role;
}

