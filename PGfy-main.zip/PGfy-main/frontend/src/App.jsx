import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Arrivals from './pages/Arrivals';
import Customer_bookings from './pages/Customer_bookings.jsx';
import './App.css';

function App() {
  return (
  
    <Router>
     
      
          <Routes>
            <Route path="/arrivals" element={<Arrivals />} />
            <Route path="/form" element={<Customer_bookings />} />
          </Routes>
  
  
    </Router>
    
  );
}

export default App;
