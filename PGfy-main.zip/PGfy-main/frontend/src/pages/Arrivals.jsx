import React from 'react';
import './Arrivals.css'; // Import the CSS file for styling

const Arrivals = () => {
  // Sample data
  const departures = [
    { name: 'John Doe', room: '101', time: '10:00 AM', mobile: '123-456-7890' },
    // Add more departure data here
  ];

  const arrivals = [
    { name: 'Jane Smith', room: '202', time: '2:00 PM', mobile: '987-654-3210' },
    // Add more arrival data here
  ];

  const renderList = (list) => (
    list.map((item, index) => (
      <div className="list-item" key={index}>
        <div className="log">LOGO</div>
        <div className="details">
          <div className="name">{item.name}</div>
          <div className="room-time">
            <span>{item.room}</span>
            <span>{item.time}</span>
          </div>
        </div>
        <div className="mobile">{item.mobile}</div>
      </div>
    ))
  );

  return (
    <div className="arrivals-container">
      <div className="section">
        <h2 className="heading">Upcoming Departures</h2>
        <p className="sub-heading">Guests checking out in next time</p>
        <div className="sub-section">
          <h3 className="sub-title">This Week</h3>
          {renderList(departures)}
        </div>
        <div className="sub-section">
          <h3 className="sub-title">This Month</h3>
          {renderList(departures)}
        </div>
        <div className="sub-section">
          <h3 className="sub-title">Specific Dates</h3>
          {renderList(departures)}
        </div>
      </div>
      <div className="section">
        <h2 className="heading">Upcoming Arrivals</h2>
        <p className="sub-heading">Guests who have booked room</p>
        <div className="sub-section">
          <h3 className="sub-title">This Week</h3>
          {renderList(arrivals)}
        </div>
        <div className="sub-section">
          <h3 className="sub-title">This Month</h3>
          {renderList(arrivals)}
        </div>
        <div className="sub-section">
          <h3 className="sub-title">Specific Dates</h3>
          {renderList(arrivals)}
        </div>
      </div>
    </div>
  );
};

export default Arrivals;
