import React from 'react';
import './Customer_bookings.css'; // Import the CSS file for styling

const Customer_bookings = () => {
  return (
    <div className="booking-container">
      <h1 className="page-title">Guest Onboarding</h1>
      <div className="form-container">
        <form>
          <h2 className="section-title">Personal Details</h2>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input type="text" id="name" name="name" />
            </div>
            <div className="form-group">
              <label htmlFor="mobile">Mobile Number</label>
              <input type="text" id="mobile" name="mobile" />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input type="email" id="email" name="email" />
            </div>
          </div>

          <h2 className="section-title">Government ID</h2>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="id-type">ID Type</label>
              <select id="id-type" name="id-type">
                <option value="passport">Passport</option>
                <option value="driving-license">Driving License</option>
                <option value="aadhaar">Aadhaar</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="id-number">ID Number</label>
              <input type="text" id="id-number" name="id-number" />
            </div>
          </div>

          <h2 className="section-title">Permanent Address</h2>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="address">Address</label>
              <input type="text" id="address" name="address" />
            </div>
          </div>

          <h2 className="section-title">Emergency Contact</h2>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="emergency-contact">Contact Number</label>
              <input type="text" id="emergency-contact" name="emergency-contact" />
            </div>
          </div>

          <div className="form-row">
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Customer_bookings;
