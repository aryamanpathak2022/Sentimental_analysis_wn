import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import pgfy from "../../assets/PGfy.jpeg";
import { FormControl } from '@material-ui/core';
import { InputLabel } from '@material-ui/core';
import { Input} from '@material-ui/core';
import { InputAdornment } from '@material-ui/core';
import { IconButton } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';


const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    width: theme.spacing(15),
    height: theme.spacing(15),
    borderRadius: 'none',
    backgroundColor: 'white'
  },
  submit: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor: 'black',//'#2563EB',
    textTransform: 'none',
    fontSize : '1rem',
  },
  submitChildren: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor : 'black',
    borderTopRightRadius : '0px',
    borderBottomRightRadius : '0px',
    borderTopLeftRadius : '20px',
    borderBottomLeftRadius : '20px',
    textTransform: 'none',
    fontSize : '1rem',
  },
  submitChildrenActive: {
    margin: theme.spacing(2, 0, 2),
    color : 'black',
    backgroundColor : 'rgb(254, 254, 254)',
    borderTopRightRadius : '20px',
    borderBottomRightRadius : '20px',
    borderTopLeftRadius : '0px',
    borderBottomLeftRadius : '0px',
    textTransform: 'none',
    fontSize : '1rem',
  },
  noHover : {
    pointerEvents : 'none'
  }
}
));

export default function SignIn() {
  const classes = useStyles();
  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <Container component="main" className = "flex justify-center">
      <CssBaseline/>
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <img src={pgfy} alt="pgfy" />
        </Avatar>
        <div style = {{width : '50%'}} component="h2" variant="h5" className = "font-bold text-4xl m-1 mt-6 text-center">
           We simplify PG Management in India
        </div>
        <form className="mt-6" style = {{width : '55%'}} noValidate>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="email"
            label="Username, Email or Mobile"
            name="email"
            autoComplete="email"
            autoFocus
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            type={showPassword ? 'text' : 'password'}
            fullWidth
            id="password"
            label="Password"
            name="password"
            autoComplete="password"
            autoFocus

            InputProps={{
              endAdornment:(<InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>)
            }}
          />
        <div className="flex items-center justify-between mt-2">
            <Grid item>
              <FormControlLabel
                    control={<Checkbox value="remember" color="primary" />}
                    label="Remember me"
                />
            </Grid>
            <Grid className="flex justify-center">
                <a href="#" variant="body2" className="text-blue-600">
                  Forgot your password?
                </a>
            </Grid>
          </div>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className= {`${classes.submit} text-lg ${classes.noHover}`}
          >
            Sign In
          </Button>
              <Link href="#" variant="body2">
                {"Don't have an account? Sign Up"}
              </Link>
        </form>
      </div>
      <Box mt={8}>
      </Box>
    </Container>
  );
}