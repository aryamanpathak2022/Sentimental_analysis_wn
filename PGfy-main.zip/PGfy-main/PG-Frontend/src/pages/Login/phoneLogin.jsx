import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import pgfy from "../../assets/PGfy.jpeg";
import { InputAdornment } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    width: theme.spacing(15),
    height: theme.spacing(15),
    borderRadius: 'none',
    backgroundColor: 'white'
  },
  submit: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor: 'black',
    textTransform: 'none',
    fontSize : '1rem',
  },
  noHover : {
    pointerEvents : 'none'
  }
}
));

export default function SignIn() {
  const classes = useStyles();

  return (
    <Container component="main" className = "flex justify-center">
      <CssBaseline/>
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <img src={pgfy} alt="pgfy" />
        </Avatar>
        <div style = {{width : '40%'}} component="h2" variant="h5" className = "font-bold text-4xl m-1 mt-6 text-center">
          Login to Manage your PG/Hostel instantly
        </div>
        <form className="mt-6" style = {{width : '55%'}} noValidate>
        <div>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="phone-Number"
            label="Mobile Number"
            name="phone-Number"
            autoComplete="phone-Number"
            autoFocus
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  +91
                </InputAdornment>
              ),
            }}
          />
        </div>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className= {`${classes.submit} text-lg ${classes.noHover} `}
          >
            Send OTP
          </Button>
              <Link href="#" variant="body2">
                {"Don't have an account? Sign Up"}
              </Link>
        </form>
      </div>
      <Box mt={8}>
      </Box>
    </Container>
  );
}