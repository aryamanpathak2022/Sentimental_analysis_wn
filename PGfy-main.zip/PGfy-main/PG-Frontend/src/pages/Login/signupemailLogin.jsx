import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import pgfy from "../../assets/PGfy.jpeg";
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { FormControl } from '@material-ui/core';
import { InputLabel } from '@material-ui/core';
import { Input} from '@material-ui/core';
import { InputAdornment } from '@material-ui/core';
import { IconButton } from '@mui/material'; 


const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    width: theme.spacing(15),
    height: theme.spacing(15),
    borderRadius: 'none',
    backgroundColor: 'white'
  },
  submit: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor: 'black',//'#2563EB',
    textTransform: 'none',
    fontSize : '1rem',
  },
  noHover : {
    pointerEvents : 'none'
  }
}
));

export default function SignIn() {
  const classes = useStyles();

  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClickShowConfirmPassword = () => setShowConfirmPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleMouseDownConfirmPassword = (event) => {
    event.preventDefault();
  };

  return (
    <Container component="main" className = "flex justify-center">
      <CssBaseline/>
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <img src={pgfy} alt="pgfy" />
        </Avatar>
        <div style = {{width : '50%'}} component="h2" variant="h5" className = "font-bold text-4xl m-1 mt-6 text-center">
           We simplify PG Management in India
        </div>
        <form className="mt-6" style = {{width : '55%'}} noValidate>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="email"
            label="Username"
            name="email"
            autoComplete="email"
            autoFocus
          />
          <Box className='flex justify-between'>
            <TextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                id="phone"
                label="Mobile Number"
                name="phone"
                autoComplete="phone"
                autoFocus
                style = {{width : '48%'}}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      +91
                    </InputAdornment>
                  ),
                }}
              />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
              style = {{width : '48%'}}
            />
          </Box>
          <Box className='flex justify-between'>
          <TextField
          variant="outlined"
          margin="normal"
          required
          type={showPassword ? 'text' : 'password'}
          fullWidth
          id="new-password"
          label="New Password"
          name="new-password"
          autoComplete="new-password"
          autoFocus
          style = {{width : '48%'}}

          InputProps={{
            endAdornment:(<InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>)
          }}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          type={showConfirmPassword ? 'text' : 'password'}
          fullWidth
          id="confirm-password"
          label="Confirm Password"
          name="confirm-password"
          autoComplete="confirm-password"
          style = {{width : '48%'}}
          autoFocus

          InputProps={{
            endAdornment:(<InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowConfirmPassword}
                onMouseDown={handleMouseDownConfirmPassword}
              >
                {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>)
          }}
        />
        </Box>
        <div className="flex items-center justify-between mt-2">
            <Grid item>
              <FormControlLabel
                    control={<Checkbox value="remember" color="primary" />}
                    label="Remember me"
                />
            </Grid>
            <Grid className="flex justify-center">
                <a href="#" variant="body2" className="text-blue-600">
                  Forgot your password?
                </a>
            </Grid>
          </div>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className= {`${classes.submit} text-lg ${classes.noHover}`}
          >
            Sign Up
          </Button>
              <Link href="#" variant="body2">
                {"Existing User? Sign In"}
              </Link>
        </form>
      </div>
      <Box mt={8}>
      </Box>
    </Container>
  );
}