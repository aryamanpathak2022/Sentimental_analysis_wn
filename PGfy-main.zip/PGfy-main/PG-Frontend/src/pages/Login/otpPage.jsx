import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import OTP from '../../components/otp.jsx'

import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import pgfy from "../../assets/PGfy.jpeg";
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { FormControl } from '@material-ui/core';
import { InputLabel } from '@material-ui/core';
import { Input} from '@material-ui/core';
import { InputAdornment } from '@material-ui/core';
import { IconButton } from '@mui/material'; 

// import Avatar from '@material-ui/core/Avatar';
// import CssBaseline from '@material-ui/core/CssBaseline';
// import TextField from '@material-ui/core/TextField';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Checkbox from '@material-ui/core/Checkbox';
// import Link from '@material-ui/core/Link';
// import Grid from '@material-ui/core/Grid';
// import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
// import Container from '@material-ui/core/Container';
// import pgfy from "../assets/PGfy.jpeg";
// import Visibility from '@mui/icons-material/Visibility';
// import VisibilityOff from '@mui/icons-material/VisibilityOff';
// import { FormControl } from '@material-ui/core';
// import { InputLabel } from '@material-ui/core';
// import { Input} from '@material-ui/core';
// import { InputAdornment } from '@material-ui/core';
// import { IconButton } from '@mui/material'; 

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    width: theme.spacing(15),
    height: theme.spacing(15),
    borderRadius: 'none',
    backgroundColor: 'white'
  },
  submit: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor: 'black',//'#2563EB',
    textTransform: 'none',
    fontSize : '1rem',
  },
  noHover : {
    textTransform: 'none',
    pointerEvents : 'none'
  },
}
));

export default function BasicCard() {
    const [otpLength, setOtpLength] = React.useState(6);

    const classes = useStyles();

    return (
      <Container component="main" className = "flex justify-center">
      <CssBaseline/>
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <img src={pgfy} alt="pgfy" />
        </Avatar>
        <Card className={`flex justify-center w-[40%]${classes.paper} mt-5`}>
          <CardContent sx ={{ width: '90%'}}>
          <div className='flex flex-col gap-10 justify-between'>
          <div className='flex flex-col gap-3 justify-between'>
              <div component="h2" variant="h5" className = "font-bold text-4xl m-1 mt-6">
                 Enter OTP
              </div>
              <Typography sx={{ mb: 1.5, fontSize : '1.1rem'}} color="text.secondary">
                Please enter the one-time password you receive to authenticate your account.
              </Typography>
            </div>
            {/* <Typography variant="body2">
              well meaning and kindly.
              <br />
              {'"a benevolent smile"'}
            </Typography> */}
              <OTP length = {6}/> 
            <Box sx ={{ mt: 1, width: '100%' }} className='flex justify-between items-center'>
              <Typography color="text.secondary" style={{ textDecoration: 'none' }}>
                  <span
                    style={{
                      textDecoration: 'none',
                      cursor: 'pointer',
                      display: 'inline-block',
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.textDecoration = 'underline';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.textDecoration = 'none';
                    }}
                    onClick = {() => {console.log("clicked")}}
                  >
                    Resend OTP
                  </span>
                </Typography>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  style ={{ width: '20%'}}
                  className= {`${classes.submit} text-lg ${classes.noHover}`}
                >
                  Verify
                </Button>
            </Box>
            </div>
          </CardContent>
        </Card>
      </div>
      </Container>
    );
  }