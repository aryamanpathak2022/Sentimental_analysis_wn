import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import pgfy from "../assets/PGfy.jpeg";
import { FormControl } from '@material-ui/core';
import { InputLabel } from '@material-ui/core';
import { Input} from '@material-ui/core';
import { InputAdornment } from '@material-ui/core';
import { IconButton } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import TextArea from '../components/textArea.jsx'


const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    width: theme.spacing(15),
    height: theme.spacing(15),
    borderRadius: 'none',
    backgroundColor: 'white'
  },
  submit: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor: 'black',//'#2563EB',
    textTransform: 'none',
    fontSize : '1rem',
  },
  submitChildren: {
    margin: theme.spacing(2, 0, 2),
    backgroundColor : 'black',
    borderTopRightRadius : '0px',
    borderBottomRightRadius : '0px',
    borderTopLeftRadius : '20px',
    borderBottomLeftRadius : '20px',
    textTransform: 'none',
    fontSize : '1rem',
  },
  submitChildrenActive: {
    margin: theme.spacing(2, 0, 2),
    color : 'black',
    backgroundColor : 'rgb(254, 254, 254)',
    borderTopRightRadius : '20px',
    borderBottomRightRadius : '20px',
    borderTopLeftRadius : '0px',
    borderBottomLeftRadius : '0px',
    textTransform: 'none',
    fontSize : '1rem',
  },
  noHover : {
    pointerEvents : 'none'
  }
}
));

export default function SignIn() {
  const classes = useStyles();
  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <Container component="main" className = "flex justify-center">
      <CssBaseline/>
      <div className={classes.paper}>
        <h3 style={{ width: '50%' }} variant="h4" className="font-bold text-3xl m-1 mt-6 text-center">
            Register your PG here
        </h3>
        <h1 style={{ width: '50%' }} variant="h6" className="font-bold text-4xl m-1 mt-6 text-center">
            PGfy: Paying Guest for You 
        </h1>
        <h6 className = "font-500 text-lg m-1 mt-3 text-center">
            We simplify PG Management in India
        </h6>

        <form className="mt-6" style = {{width : '55%'}} noValidate>
            <div className='flex flex-col gap-4 justify-between'>
            <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        PG Name
                    </span>
                </Typography>
                <TextArea length={1}/>
          </div>
          <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        Owner Name
                    </span>
                </Typography>
                <TextArea length={1}/>
          </div>
          <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        GST Number
                    </span>
                </Typography>
                <TextArea length={1}/>
          </div>
          <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        Address
                    </span>
                </Typography>
                <TextArea length={3}/>
          </div>
          <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        Mobile Number
                    </span>
                </Typography>
                <TextArea length={1}/>          
            </div>
          <div>
                <Typography color="text.secondary" style={{ textDecoration: 'none' , marginBottom: '1'}}>
                    <span className="text-gray-500">
                        Email
                    </span>
                </Typography>
                <TextArea length={1}/>
          </div>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className= {`${classes.submit} text-lg ${classes.noHover}`}
          >
            Sign In
          </Button>
          </div>
        </form>
      </div>
      <Box mt={8}>
      </Box>
    </Container>
  );
}