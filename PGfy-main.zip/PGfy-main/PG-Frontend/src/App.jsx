import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import EmailLogin from './pages/Login/emailLogin.jsx';
import PhoneLogin from './pages/Login/phoneLogin.jsx';
import SignUpEmailLogin from './pages/Login/signupemailLogin.jsx';
import OtpPage from './pages/Login/otpPage.jsx';
import Registration from './pages/registration.jsx';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<EmailLogin />} />
        <Route path="/forgot-password" element={<PhoneLogin />} />
        <Route path="/signup" element={<SignUpEmailLogin />} />
        <Route path="/otp" element={<OtpPage />} />
        <Route path="/registration" element={<Registration />} />
      </Routes>
    </Router>
  );
}

export default App;
